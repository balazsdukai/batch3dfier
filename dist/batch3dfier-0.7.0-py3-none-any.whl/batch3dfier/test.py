import csv
from io import StringIO
p="/home/bdukai/Data/3DBAG/t_25gn1_c1.csv" 
with open(p, "r") as f_in:
    csv_in = []
    reader = csv.DictReader(f_in)
    for row in reader:
        row.pop('') # remove trailing commas from the CSV (until #58 is fixed in 3dfier)
        row['ahn_file_date'] = "2014-02-12"
        csv_in.append(row)
    

with open(p, "r") as f_in:
    next(f_in)
    for row in f_in:
#         l = row.readline()
        f = StringIO(row+"2014-02-12")