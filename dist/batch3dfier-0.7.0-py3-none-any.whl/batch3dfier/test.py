import csv
from io import StringIO
from subprocess import run
from livereload.server import shell
p="/home/bdukai/Data/3DBAG/t_25gn1_c1.csv" 
with open(p, "r") as f_in:
    csv_in = []
    reader = csv.DictReader(f_in)
    for row in reader:
        row.pop('') # remove trailing commas from the CSV (until #58 is fixed in 3dfier)
        row['ahn_file_date'] = "2014-02-12"
        csv_in.append(row)
    

with open(p, "r") as f_in:
    next(f_in)
    for row in f_in:
#         l = row.readline()
        f = StringIO(row+"2014-02-12")
        cur.copy_from(f, tbl, sep=',')
        

p="/home/bdukai/Data/3DBAG/t_25gn1_c1.csv" 
date="2014-02-01"
command = "gawk -i inplace -F',' 'BEGIN { OFS = \",\" } {$16=\"%s\"; print}' %s" % (date, p)
run(command, shell=True)
command = "sed -i '1s/.*/id,ground-0.00,ground-0.10,ground-0.20,ground-0.30,\
ground-0.40,ground-0.50,roof-0.00,roof-0.10,roof-0.25,roof-0.50,roof-0.75,\
roof-0.90,roof-0.95,roof-0.99,ahn_file_date/' %s" % p
run(command, shell=True)

