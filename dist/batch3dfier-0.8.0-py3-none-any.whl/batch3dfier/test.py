import yaml
from batch3dfier import config
  
# document = """
#   elevation_dirs:
#   - /path1
#   - [/path2, /path3]
# """
# a = yaml.load(document)
# print(yaml.dump(yaml.load(document)))
#  
#  
# import os.path
#  
# a = ['a/bla', ['a/foo', 'a/bar']]
# b = ['a/bla', ['a/foo', 'a/bar'], 'a/mof']
# c = [['a/bla', 'a/foo'], 'a/bar', 'a/mof']
# d = ['a/bla', 'a/foo', 'a/bar', 'a/mof']
#  
#  
# def add_abspath(dirs_list):
#     """Recursively append the absolute path to the paths in a nested list"""
#     for i, elem in enumerate(dirs_list):
#         if isinstance(elem, str):
#             dirs_list[i] = os.path.abspath(elem)
#         else:
#             dirs_list[i] = add_abspath(elem)
#     return dirs_list
#  
# add_abspath(a)
#  
#  
# #####
# tiles = ['1', '2', '3a']
# tiles = ['1', '2']

from pprint import pprint

# tile_case = ['lower', 'lower', ['upper', 'lower']]
dataset_name = ['a_{tile}.laz', 'a_{tile}.laz', 
                ['b_{tile}.laz', 'c{tile}.laz', 'o-{tile}.laz'],
                'a_{tile}.laz']
pc_dir = ['/home/bdukai/Development/batch3dfier/example_data',
          '/home/bdukai/Development/batch3dfier/example_data/ahn3',
          ['/home/bdukai/Development/batch3dfier/example_data/ahn2/ground',
           '/home/bdukai/Development/batch3dfier/example_data/ahn2/rest',
           '/home/bdukai/Development/batch3dfier/example_data/ahn2/other'],
          '/home/bdukai/Development/batch3dfier/example_data/ahn1']

d = config.pc_name_dict(pc_dir, dataset_name)

import os
import re


def get_priority(d):
    return(d[1]['priority'])
d_sort = sorted(d.items(), key=get_priority)


f_idx = {}
for i, elem in enumerate(d_sort):
    idx = {}
    name = elem[1]['name']
    l = name[:name.find('{')]
    r = name[name.find('}')+1:]
    reg = '(?<=' + l + ').*(?=' + r + ')'
    t_pat = re.compile(reg, re.IGNORECASE)
    for item in os.listdir(elem[0]):
        path = os.path.join(elem[0], item)
        if os.path.isfile(path):
            pc_tile = t_pat.search(item)
            if pc_tile:
                tile = pc_tile.group(0).lower()
                idx[tile] = [path]
    f_idx[elem[0]] = idx


# d_sort is [('/some/path', {'name': 'a_{tile}.laz', 'priority': 0}), ...]
file_index = {}
pri = []
for dir in reversed(d_sort):
    dirname = dir[0]
    if len(pri) == 0:
        file_index = f_idx[dirname]
    else:
        if pri[-1] == dir[1]['priority']:
            tiles = f_idx[dirname].keys()
            for t in tiles:
                try:
                    file_index[t] += f_idx[dirname][t]
                except KeyError:
                    file_index[t] = f_idx[dirname][t]
        else:
            f = {**file_index, **f_idx[dirname]}
            file_index = f
    pri.append(dir[1]['priority'])

pprint(file_index)

test = {
    '1': ['/home/bdukai/Development/batch3dfier/example_data/a_1.laz'],
    '2': ['/home/bdukai/Development/batch3dfier/example_data/ahn3/a_2.laz'],
    '3a': ['/home/bdukai/Development/batch3dfier/example_data/ahn2/rest/c3a.laz',
           '/home/bdukai/Development/batch3dfier/example_data/ahn2/ground/B_3A.laz',
           '/home/bdukai/Development/batch3dfier/example_data/ahn2/other/o-3a.laz'],
    '4b': ['/home/bdukai/Development/batch3dfier/example_data/ahn2/ground/B_4B.laz'],
    '6': ['/home/bdukai/Development/batch3dfier/example_data/ahn2/other/o-6.laz']}

print(file_index == test)

# 
# f_idx[a]
# f_idx[b]
# # join priority 0 and 1
# # a overwrites b
# {**f_idx[b], **f_idx[a]}
# 
# # join both priority 2
# tiles = set([f for i in [c, d] for f in f_idx[i].keys()])
# t_idx = {t: [] for t in tiles}
# for i in [c, d]:
#     for t in tiles:
#         try:
#             t_idx[t] += f_idx[i][t]
#         except KeyError:
#             print('nope')
# pprint(t_idx)
# 
# a = '/home/bdukai/Development/batch3dfier/example_data'
# b = '/home/bdukai/Development/batch3dfier/example_data/ahn3'
# d = '/home/bdukai/Development/batch3dfier/example_data/ahn2/ground'
# c = '/home/bdukai/Development/batch3dfier/example_data/ahn2/rest'

