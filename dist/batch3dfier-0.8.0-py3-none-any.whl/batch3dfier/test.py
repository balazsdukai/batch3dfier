import yaml
from batch3dfier import db
from batch3dfier import bag3d

current = db.db(
        dbname='bag_current',
        host='localhost',
        port='5432',
        user='bag_user1',
        password='bag2017')

path = "/home/bdukai/Data/3DBAG/test.csv"

with open(path, "r") as f_in:
    next(f_in) # skip header
    for l in f_in:
        print(l)


with current.conn:
    with current.conn.cursor() as cur:
        with open(path, "r") as f_in:
            next(f_in) # skip header
            cur.copy_from(f_in, "bagactueel.heights", sep=',', null='-99.99')
            

def a(a, *b):
    print(a)
    if b:
        print(b)
    else:
        print("no b") 