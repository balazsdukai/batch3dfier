from batch3dfier.batch3dfierapp import __version__, __copyright__, __author__, __licence__

__all__ = ['__version__', '__copyright__', '__author__', '__licence__']